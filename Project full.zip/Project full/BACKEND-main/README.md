# waste management application
